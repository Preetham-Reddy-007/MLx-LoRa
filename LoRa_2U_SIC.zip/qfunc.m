function Q=qfunc(x)
Q=erfc(x/sqrt(2))/2;
end