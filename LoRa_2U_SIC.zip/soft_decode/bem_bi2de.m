function d=bem_bi2de(b)
% simple function for calculating decimal d form binary b

b = b(:,end:-1:1); %'left-msb'
pow2vector = 2.^(0:1:(size(b,2)-1));
size_B = size(b,2);
d = b(:,1:size_B)*pow2vector(:,1:size_B).';