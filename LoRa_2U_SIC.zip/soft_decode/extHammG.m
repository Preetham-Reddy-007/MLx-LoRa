function G_ext=extHammG(G)
% Changes the normal generator matrix G to the extended 
% generator matrix G_ext

M=size(G,1);
G_ext=[G zeros(M,1)];
for k=1:M
    if mod(sum(G(k,:)),2)==1
        G_ext(k,end)=1;
    end
end