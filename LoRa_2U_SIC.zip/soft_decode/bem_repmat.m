function B = bem_repmat(A,M)
% simple repmat function 
% generates a matrix B with M row out of a column vector A

B = A(ones(M, 1), :);

