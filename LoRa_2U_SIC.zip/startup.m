function startup

p = genpath(pwd);
addpath(p);
