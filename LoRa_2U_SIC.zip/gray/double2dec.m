function [out] = double2dec(in)
% get the decimal representation of a binary input with double type (MSB left)
out = zeros(size(in,1),1);
for i=1:size(in,1)
%     out(i) = bin2dec(num2str(in(i,:)));   % very slow
    for j=1:size(in,2)
        out(i) = out(i)+in(i,j)*2^(size(in,2)-j);
    end
end
