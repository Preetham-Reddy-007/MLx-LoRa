## A Two-User Successive Interference Cancellation LoRa Receiver with Soft-Decoding

1. Run the startup script startup.m
2. Create the folders "results/Monte-Carlo/"
3. Run param_MC_MU.m
4. The simulated BERs correspond to the BERs of Fig. 8 with N_I = 2 in the paper J. Tapparel et al., "Enhancing the Reliability of Dense LoRaWAN Networks with
Multi-User Receivers", IEEE Open Journal of the Communications Society, 2021.

The Monte-Carlo simulation parameters can be modified in param_MC_MU.m
